Created [review.json](/data/work/tmp/skill-up-1950814547/review.json) with four reviews in input order. JSON validation passed.
